#ifndef __TIMER_PWM_H__
#define __TIMER_PWM_H__

#include <gd32f30x.h>

void gpio_pwm_config(void);

void timer_pwm_config(void);


#endif

