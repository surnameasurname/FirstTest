#ifndef __TIMER_H__
#define __TIMER_H__

#include <gd32f30x.h>

void timer1_init(void);


#endif

