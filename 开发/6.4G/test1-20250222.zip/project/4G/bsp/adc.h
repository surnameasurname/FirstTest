#include "gd32f30x.h"



void adc_init(void);
