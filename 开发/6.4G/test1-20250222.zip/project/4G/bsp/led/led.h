#ifndef __LED_H__
#define __LED_H__

#include <gd32f30x.h>

void  led_init (void);
void led_on(int lednum);
void led_off(int lednum);



#endif

