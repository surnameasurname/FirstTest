#include "sys.h"
#include "uart.h"
#include "delay.h"
#include "adc.h"
#include "stmflash.h" 
#include "time.h"
#include "communication1.h"
#include "lora.h"
#include "equipment.h"
#include "MySPI.h"
int main(void)
{
	Mode = 1;			//���㴫��
	Stm32_Clock_Init(9); //ϵͳʱ������
	delay_init(72); //��ʱ��ʼ��
	AdcInit();
	communication1_init();
	TIM3_Int_Init(9999,7199);//1��
	Time3En(1);
	InitLora();
	ReadAllData();
	SPI_Init();
	delay_ms(100);

	
	M1 = 0;
	M0 = 1;
	delay_ms(100);
	SetLora();
	
	while(1)
	{
		
		if(SendTime != 0){
				SendTime = 0;
				if(ReceiveOrSend == 1){
					ADC_1 = GetAdcAverage(ADC_CH6,10);
					ADC_2 = GetAdcAverage(ADC_CH5,10);
					
					Lora_SendAdc();
				}		
				
		}
			Modbus_Event_1();
			DAC_Receive();

	}


}
