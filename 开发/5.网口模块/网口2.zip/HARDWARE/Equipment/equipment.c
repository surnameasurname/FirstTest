#include "equipment.h"
u32 PB3Count = 0;
u32 PB4Count = 0;
u32 PB5Count = 0;
u32 PB6Count = 0;
u32 PB7Count = 0;

u8 PB3Current = 0;
u8 PB4Current = 0;
u8 PB5Current = 0;
u8 PB6Current = 0;
u8 PB7Current = 0;

u8 PB3New = 0;
u8 PB4New = 0;
u8 PB5New = 0;
u8 PB6New = 0;
u8 PB7New = 0;

u8 WorkCount = 0;			//�˿�PB3�ļ�ʱ  10��

