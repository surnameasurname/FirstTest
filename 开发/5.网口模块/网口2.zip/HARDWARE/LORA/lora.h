#include "sys.h"
#define AUX	PBin(13) //PB13

#define M1	PAout(11) //PA11
#define M0	PAout(12) //PA12

void InitLoraGpio(void);
void InitLora(void);
void InitLoraGpio(void);


void ReadRegister(u8 Reg);


