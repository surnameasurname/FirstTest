#include "delay.h"
#include "sys.h" 
#include "communication.h"
#include "uart.h"
#include "time.h" 
#include "led.h"
#include "gpio.h"
#include "water.h"
#include "global.h"
#include "electricmachine.h"
#include "wash.h"
#include "DataChange.h"
#include "stmflash.h"
#include "communication2.h"

int main(void)
{
	Stm32_Clock_Init(9);
	delay_init(72);
	communication_init();
	
	TIM3_Int_Init(9999,7199);//1��
	Time3En(1);
	SendTime=0;
	LED_Init();		  			//��ʼ����LED���ӵ�Ӳ���ӿ�
	InitGpio();
	Initmachine();
	uart1_init(72,38400);	//����1��ʼ��
	
	//ˮλ���
	Water1 = 1;
	Water2 = 1;
	//����ָʾ��
	WORKLED = 1;
	//�������ʹ�ܶ˿�
	MOT_EN = 1;
	ReadSecond();
	ReadFirst();
	ReadThird();
	ReadTimes();
	if(First == 0x0000 || First == 0xffff){
		First = 15500;
	}
	if(Second == 0x0000 || Second == 0xffff){
		Second = 18500;
	}
	if(Third		== 0x0000 || Third == 0xffff){
		Third = 20000;
	}
	if(Third		== 0x0000 || Third == 0xffff){
		Third = 20000;
	}
	if(RemWashTimes		== 0x0000 || RemWashTimes == 0xffff){
		RemWashTimes = 1;
	}
	delay_us(1000);
	send_uart2('A');
	send_uart2('A');
	send_uart2(':');
	send_uart2_string(DataChangeNumberToString(First));
	send_uart2(',');
	send_uart2('B');
	send_uart2(':');
	send_uart2_string(DataChangeNumberToString(Second));
	send_uart2(',');
	send_uart2('C');
	send_uart2(':');
	send_uart2_string(DataChangeNumberToString(Third));
	send_uart2(',');
	send_uart2('D');
	send_uart2(':');
	send_uart2_string(DataChangeNumberToString(RemWashTimes));
	send_uart2(';');
	send_uart2('*');
		
	//�����л�FanChange ���仯�˾���Ϊ1   ������ڷ��ټ���ʱ���л�����5min�ٴμ�⣬��������ڷ��ټ���ʱ���⣬��ʱ20S

	
	while(1)
	{
		//���عر�
		if(Switch == 0)
		{
			
				if(FANAD1 == 0){
									//����
							if(GearPosition == 0){
								GearPosition = 1;
							}else{
								GearPosition = 1;
								FanChange = 1;
							}
							//send_uart2('1');
							
							while(FANAD1 == 0){
										order_dispose_u2();

										//���ˮλ
										TestWater();
										//�������ټ��
										if(MeasuringSpeedSignal == 1)
										{
												if(MotorSignal == 1){
													//�����������
													MotorSignal=2;
													StepperMotorState = 1;
													MachineHalfTurn();
													//WriteStepperMotorState();
												
												}
												if(NoWater == 0){		//��ˮֹͣ���
													//�����������ʱ5S
													if(MotorDelay >= 5){
															if(NewNumber != 0)		
															{
																NewNumber = 0;
																EqipmentModbusMonitor();		//ÿ��һ��
															}
															Modbus_Event_1();								//����Modbus���ص���Ϣ
													}
													
												}
										}
										else
										{
												if(MotorSignal == 3)
												{
														MotorSignal = 4;
														StepperMotorState = 0;
														MachineResetting();				//�رղ������
														//WriteStepperMotorState();
												}
										}
										//�ж���ϴ
										if(number >= 59){								//���������
												CSpeed = CSpeed/60;
												send_uart2('-');
												send_uart2('-');
												send_uart2_string(DataChangeNumberToString(CSpeed));
												
												number = 0;
												//WriteFirstTime();
												//if(CSpeed <= Third)
												if(CSpeed <= Third)
												{
													if(EnFanRestart == 0)
													{
														EnWash = 1;
														//��ϴָʾ��  ����60S����ϴ  ��OpenWash  ��1
														LED2 = 1;
													}
													
												}
												//delay_ms(10);
												if(CSpeed > 1)
												{
														IntervalOpening = 1;
														EnWash = 0;
														LED2 = 0;
												}
												CSpeed = 0;
												
										}
										
										if(NoWater == 0){			//��ˮ
												if(EnPump == 1){
													PumpOn=1;
													EnPump = 0;
												}
												if(OpenWash == 1){
												//��ϴ
												WashOnce();
												
												//ָʾ����ʱ10��
												}
												if(GreenLedNumber >= 10){
													LED2 = 0;
													EnGreenLed = 0;
													GreenLedNumber = 0;
													IntervalOpening = 1;
												}
										}
										if(NoWater == 1)
										{
												//��¼��ϴ��״̬  ��ˮ��ֵ����ϴ
												RememberState();
										}
							
							
							}
			
				
				
				
				}
				
				if(FANAD2 == 1){
									//����
							if(GearPosition == 0){
								GearPosition = 2;
							}else{
								GearPosition = 2;
								FanChange = 1;
							}
							send_uart2('2');
							while(FANAD2 == 1){
										order_dispose_u2();
										//���ˮλ
										TestWater();
										//�������ټ��
										if(MeasuringSpeedSignal == 1)
										{
												if(MotorSignal == 1){
													//�����������
													MotorSignal=2;	
													StepperMotorState = 1;
													MachineHalfTurn();
													//WriteStepperMotorState();
												
												}
												if(NoWater == 0){		//��ˮֹͣ���
													//�����������ʱ5S
													if(MotorDelay >= 5){
															if(NewNumber != 0)		
															{
																NewNumber = 0;
																EqipmentModbusMonitor();		//ÿ��һ��
															}
															Modbus_Event_1();								//����Modbus���ص���Ϣ
													}
													
												}
										}
										else
										{
												if(MotorSignal == 3)
												{
														MotorSignal = 4;
														StepperMotorState = 0;
														MachineResetting();													//�رղ������
														//WriteStepperMotorState();
												}
										}
										//�ж���ϴ18500
										if(number >= 59){								//���������
												CSpeed = CSpeed/60;
												send_uart2('-');
												send_uart2('-');
												send_uart2_string(DataChangeNumberToString(CSpeed));
												
												number = 0;
												//WriteFirstTime();
												if(CSpeed <= Second)
												{
													if(EnFanRestart == 0)
													{
														EnWash = 1;
														//��ϴָʾ��  ����60S����ϴ  ��OpenWash  ��1
														LED2 = 1;
													}
													
												}
												//delay_ms(10);
												if(CSpeed > Second)
												{
														IntervalOpening = 1;
														EnWash = 0;
														LED2 = 0;
												}
												CSpeed = 0;
												
										}
										
										if(NoWater == 0){			//��ˮ
												if(EnPump == 1){
													PumpOn=1;
													EnPump = 0;
												}
												if(OpenWash == 1){
												//��ϴ
												WashOnce();
												
												//ָʾ����ʱ10��
												}
												if(GreenLedNumber >= 10){
													LED2 = 0;
													EnGreenLed = 0;
													GreenLedNumber = 0;
													IntervalOpening = 1;
												}
										}
										if(NoWater == 1)
										{
												//��¼��ϴ��״̬  ��ˮ��ֵ����ϴ
												RememberState();
										}
							
							
							}
			
				
				
				
				}
				if(FANAD3 == 1){
									//����
							if(GearPosition == 0){
								GearPosition = 3;
							}else{
								GearPosition = 3;
								FanChange = 1;
							}
							send_uart2('3');
							while(FANAD3 == 1){
										order_dispose_u2();
										//���ˮλ
										TestWater();
										//�������ټ��
										if(MeasuringSpeedSignal == 1)
										{
												if(MotorSignal == 1){
													//�����������
													MotorSignal=2;			
													StepperMotorState = 1;
													MachineHalfTurn();
													//WriteStepperMotorState();
												
												}
												if(NoWater == 0){		//��ˮֹͣ���
													//�����������ʱ5S
													if(MotorDelay >= 5){
															if(NewNumber != 0)		
															{
																NewNumber = 0;
																EqipmentModbusMonitor();		//ÿ��һ��
															}
															Modbus_Event_1();								//����Modbus���ص���Ϣ
													}
													
												}
										}
										else
										{
												if(MotorSignal == 3)
												{
														MotorSignal = 4;
														StepperMotorState = 0;
														MachineResetting();				//�رղ������
														//WriteStepperMotorState();
												}
										}
										//�ж���ϴ  15500
										if(number >= 59){								//���������
												CSpeed = CSpeed/60;
												send_uart2('-');
												send_uart2('-');
												send_uart2_string(DataChangeNumberToString(CSpeed));
												
												number = 0;
												//WriteFirstTime();
												if(CSpeed <= First)
												{
													if(EnFanRestart == 0)
													{
														EnWash = 1;
														//��ϴָʾ��  ����60S����ϴ  ��OpenWash  ��1
														LED2 = 1;
													}
													
												}
												//delay_ms(10);
												if(CSpeed > 15500)
												{
														IntervalOpening = 1;
														EnWash = 0;
														LED2 = 0;
												}
												CSpeed = 0;
												
										}
										
										if(NoWater == 0){			//��ˮ
												if(EnPump == 1){
													PumpOn=1;
													EnPump = 0;
												}
												if(OpenWash == 1){
												//��ϴ
												WashOnce();
												
												//ָʾ����ʱ10��
												}
												if(GreenLedNumber >= 10){
													LED2 = 0;
													EnGreenLed = 0;
													GreenLedNumber = 0;
													IntervalOpening = 1;
												}
										}
										if(NoWater == 1)
										{
												//��¼��ϴ��״̬  ��ˮ��ֵ����ϴ
												RememberState();
										}
							
							
							}
			
				
				
				
				}
			

			
		}
		//���ش�
		else
		{

			
		}

			
			
	} 
	
}








