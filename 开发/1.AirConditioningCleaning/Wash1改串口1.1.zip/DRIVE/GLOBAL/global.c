#include "global.h"

u32 WorkTime = 0;
u8 IntervalOpening = 0;
u32 IntervalTime = 0;
u8 MotorSignal = 0;					//1����		0 �ر�  //����֮����Ϊ2  ��ֹ��ο���		��Ҫ�ر���Ϊ3   �رպ���Ϊ4
u8 MeasuringSpeedSignal = 0;
u8 SendTime=0;
u16 FirstTime = 0;
u8 NoWater = 0;
u16 Speed = 0;
u32 CSpeed = 0;
u16 SaveSpeed[60];
u8 number = 0;
u8 EnWash = 0;
u8 EnWashNumber = 0;
u8 OpenWash = 0;
u16 MotorState = 0;
u8 EnGreenLed = 0;
u8 GreenLedNumber = 0;
u8 MotorDelay = 0;
u8 GearPosition = 0;
u8 FanChange = 0;
u8 EnFanDelay = 0;
u8 FanDelay = 0;
u16 FanRestart = 0;
u8 EnFanRestart = 0;
u8 NewNumber = 0;
u8 EnPump = 0;
u16 StepperMotorState = 0;
u8 Dianji_Delay = 0;
u8 En_Dianji_Delay = 0;
u16	WashTimes = 0;
u16 RemWashTimes = 1;
u16 First = 15500;
u16 Second = 18500;
u16 Third = 20000;
