#include "water.h"
#include "gpio.h"
#include "global.h"
#include "led.h"

void TestWater(void)
{
	if(Water1 ==0)	//ȱˮ
	{
		//����ˮ��
		if(WATER == 0){
			WATER = 1;
		}
	}
	else{
		//�ز�ˮ��
		if(WATER == 1){
			WATER = 0;
		}
	}
	if(Water2 == 0)	//��ˮ
	{
		NoWater = 1;
		LED1 = 1;
	}else{
		LED1 = 0;
		NoWater = 0;
	}

}
