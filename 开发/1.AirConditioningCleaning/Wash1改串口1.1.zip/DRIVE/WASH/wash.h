#include "sys.h"
#include "led.h"
#include "global.h"
#include "gpio.h"


void WashOnce(void);
void RememberState(void);






