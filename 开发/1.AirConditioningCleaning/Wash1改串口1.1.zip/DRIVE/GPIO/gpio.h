#include "sys.h"

#define Switch				PGin(1) //PG1
#define FANAD1				PGin(9) //PG9
#define FANAD2				PGin(10) //PG10
#define FANAD3				PGin(12) //PG12
//PE4	PumpOn 
#define PumpOn				PEout(4) //PE4

// Water1-PE8 Water2-PE9 UPKey-PE10 DOWNKey-PE11

#define WATER					PEout(7) //PE7  ��ˮ
#define Water1				PEin(8) //PE8  ȱˮ
#define Water2				PEin(9) //PE9  ��ˮ
#define UPKey					PEin(10) //PE10
#define DOWNKey				PEin(11) //PE11
#define Dianjizheng		PDout(4) //PD4	�����ת
#define Dianjifan			PDout(5) //PD5	�����ת
//����Ƿ��е�
#define PowerINAD			PCin(3) //PC3
void InitGpio(void);
