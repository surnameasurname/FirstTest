#include "communication2.h"

#define TOUCH_ORDER_SIZE  50											//ָ��洢�����С


//����洢�������ݵ�����
u8 communication_array_data_u2[TOUCH_ORDER_SIZE];
//�����±�
u8 communication_index_u2=0;
//����ʹ�ܱ�־λ
u8 communication_receive_en_u2=0;

//������ɱ�־λ
u8 communication_receive_done_u2=0;



//ͨ�ų�ʼ��
void communication2_init(void)
{
	uart2_init(36,19200);		//����2��ʼ��
	
	communication_index_u2=0;
	communication_receive_en_u2=0;
	communication_receive_done_u2=0;
}



void USART2_IRQHandler(void)
{
	u8 res;
	if(USART2->SR&(1<<5))//���յ�����
	{
		res=USART2->DR;
		if((communication_receive_done_u2==0))	//���յ�����ʼλ
		{
			communication_receive_en_u2=1;										//ʹ��
		}
		if(communication_receive_en_u2==1)
		{
			communication_array_data_u2[communication_index_u2++]=res;
		}
		if(res=='*')		//���յ�����λ
		{
			communication_index_u2=0;
			communication_receive_en_u2=0;
			communication_receive_done_u2=1;
		}
		//ִ�д���
	}
}

//�õ�ָ������
u16 GetCommunicationData_u2(void)
{
	u8 seeki=0,seekj=0;
	u16 CommunicationData=0;
	u8 i=0;
	for(seeki=1;seeki<TOUCH_ORDER_SIZE;seeki++)
	{
		if(communication_array_data_u2[seeki]==':')
		{
			seekj=seeki;
		}
		if(communication_array_data_u2[seeki]=='*')
		{
			break;
		}
	}
	
	if(seekj==seeki)//ָ�����
	{
		return 0;
	}
	else
	{
		i=seeki-seekj;
	}

	switch(i)
	{
		case 2:CommunicationData=communication_array_data_u2[seekj+1]-'0';
				break;
		case 3:CommunicationData=(communication_array_data_u2[seekj+1]-'0')*10+(communication_array_data_u2[seekj+2]-'0');
				break;
		case 4:CommunicationData=(communication_array_data_u2[seekj+1]-'0')*100+(communication_array_data_u2[seekj+2]-'0')*10+(communication_array_data_u2[seekj+3]-'0');
				break;
		case 5:CommunicationData=(communication_array_data_u2[seekj+1]-'0')*1000+(communication_array_data_u2[seekj+2]-'0')*100+(communication_array_data_u2[seekj+3]-'0')*10+(communication_array_data_u2[seekj+4]-'0');
				break;
		case 6:CommunicationData=(communication_array_data_u2[seekj+1]-'0')*10000+(communication_array_data_u2[seekj+2]-'0')*1000+(communication_array_data_u2[seekj+3]-'0')*100+(communication_array_data_u2[seekj+4]-'0')*10+(communication_array_data_u2[seekj+5]-'0');
				break;
			default:break;
	}
	return CommunicationData;
}


void order_dispose_u2(void){
	
		u8 number = 0;
		if(communication_receive_done_u2==1)//���һ��ָ��������
		{
			 if(communication_array_data_u2[number] == 'A'){
					First = GetCommunicationData_u2();
					WriteFirst();
					send_uart2('A');
				  send_uart2(':');
					send_uart2_string(DataChangeNumberToString(First));
					send_uart2('*');
			 }
			 if(communication_array_data_u2[number] == 'B'){
					Second = GetCommunicationData_u2();
					WriteSecond();
				  send_uart2('B');
				  send_uart2(':');
					send_uart2_string(DataChangeNumberToString(Second));
					send_uart2('*');
			 }		
			 
			 if(communication_array_data_u2[number] == 'C'){
					Third = GetCommunicationData_u2();
					WriteThird();
					send_uart2('C');
				  send_uart2(':');
					send_uart2_string(DataChangeNumberToString(Third));
					send_uart2('*');
			 }
			if(communication_array_data_u2[number] == 'D'){
					RemWashTimes = GetCommunicationData_u2();
					WriteTimes();
					send_uart2('D');
				  send_uart2(':');
					send_uart2_string(DataChangeNumberToString(RemWashTimes));
					send_uart2('*');
			 }
			 
				communication_receive_done_u2 = 0;
		
		}
		


}












