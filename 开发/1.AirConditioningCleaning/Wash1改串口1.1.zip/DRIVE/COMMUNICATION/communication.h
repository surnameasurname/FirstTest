#ifndef __communication_h_
#define __communication_h_

#include "sys.h"
#include "communication1.h"

void communication_init(void);		//ͨ�ų�ʼ��


#endif
