#include "global.h"

u32 Worktime = 0;
u8 DetectionSwitch = 0;
u32 IntervalTime = 0;

