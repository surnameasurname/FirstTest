#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

//LED�˿ڶ���
#define LED1 		PEout(13)				//
#define LED2 		PEout(12)		
#define WORKLED PEout(14)		

void LED_Init(void);	//��ʼ��		 				    
#endif

















