#include "show1.h"
#include "uart.h"
#include "communication.h"
#include "DataChange.h"
#include "equipment.h"
#include "delay.h"

void Set000(void)	//N003
{
	ShowLongOrder(N1000,Address);
}
void Set001(void)	//N005
{
	ShowLongOrder(N1008,BTL);
}
void Set002On(void)	//N001��N002
{
	ShowOrder(N1811,0x0001);
}
void Set002Down(void)	//N001��N002
{
	ShowOrder(N1811,0x0000);
}
void Set003(void)	//N030
{
	ShowLongOrder(N1080,WorkPeriod);
}
void Set004(void)	//N033
{
	ShowLongOrder(N1088,DelayTime);
}
void Set005(void)	//N015
{
	ShowLongOrder(N1010,TotalTime);
}
void Set006On(void)	//N100,101
{
		ShowOrder(N1C75,0x0001);
}
void Set006Down(void)	//N100,101
{
		ShowOrder(N1C75,0x0000);
}
void Set007(void)	//N082
{
	ShowLongOrder(N1AD8,PumpPWM);
}
void Set008(void)	//N216
{
	ShowLongOrder(N1018,CountdownTime);
}
void Set009(void)	//N016
{
	ShowLongOrder(N1020,CommunicationCheck);
}
void Set010(void)	//N017
{
	ShowLongOrder(N1028,CumulativeFrequency);
}
void Set011(void)	//N065
{
	ShowOrder(InputGear1,ComparisonVoltage1);
}
void Set012(void)	//N067
{
	ShowOrder(InputGear2,ComparisonVoltage2);
}
void Set013(void)	//N069
{
	ShowOrder(InputGear3,ComparisonVoltage3);
}
void Set014(void)	//N071
{
	ShowOrder(InputGear4,ComparisonVoltage4);
}
void Set015(void)	//N073
{
	ShowOrder(InputGear5,ComparisonVoltage5);
}
void Set016(void)	//N075
{
	ShowOrder(InputGear6,ComparisonVoltage6);
}
void Set017(void)	//N077
{
	ShowOrder(InputGear7,ComparisonVoltage7);
}
void Set018(void)	//N079
{
	ShowOrder(InputGear8,ComparisonVoltage8);
}
void Set019(void)	//N038
{
	ShowLongOrder(N1030,PressureLow);
}
void Set020(void)	//N039
{
	ShowLongOrder(N1038,PressureHigh);
}
void Set021(void)	//N092
{
	ShowLongOrder(N1040,PressureState);
}
void Set022(void)	//N042
{
	ShowLongOrder(N1048,PressureNum);
}
void Set023(void)	//N018
{
	ShowLongOrder(N1050,LightThreshold);
}
void Set024(void)	//N019
{
	ShowLongOrder(N1058,LightState);
}
void Set025(void)	//N020
{
	ShowLongOrder(N1060,LightNum);
}
void Set026(void)	//N021
{
	ShowLongOrder(N1068,SaturationThreshold);
}
void Set027(void)	//N022
{
	ShowLongOrder(N1070,SaturationState);
}
void Set044(void)
{
	ShowLongOrder(N1138,PressureThreshold);
}
void Set050(void)
{
	ShowLongOrder(IP1,IP1Data);
	ShowLongOrder(IP2,IP2Data);
	ShowLongOrder(IP3,IP3Data);
	ShowLongOrder(IP4,IP4Data);
}
void Set054(void)
{
	ShowLongOrder(Port,PortData);
}
void Set055(void)
{
	ShowLongOrder(N1140,IPAndPortChange);
}
void Set056(void)	//N262
{
	ShowLongOrder(N1078,PositiveTiming);
}
void Set028(void)	//N254
{
	ShowLongOrder(SoursData1,Particle1);	
}
void Set030(void)	//N255
{
	ShowLongOrder(SoursData2,Particle2);
}
void Set032(void)	//N256
{
	ShowLongOrder(SoursData3,Particle3);
}
void Set034(void)	//N257
{
	ShowLongOrder(SoursData4,Particle4);
}
void Set036(void)	//N258
{
	ShowLongOrder(SoursData5,Particle5);
}
void Set038(void)	//N259
{
	ShowLongOrder(SoursData6,Particle6);
}
void Set040(void)	//N260
{
	ShowLongOrder(SoursData7,Particle7);
}
void Set042(void)	//N261
{
	ShowLongOrder(SoursData8,Particle8);
}
void SetData(void)	//N202
{
	send_uart3_string("ID:SSSS202008N202");
	send_uart3_string("*");	

}

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
//0.1����

void Set060_1(void)	//��ַ
{
	ShowLongOrder(N1400,Address);
}
void Set001_1(void)		//������������(��)������Ĭ��6��
{
	ShowLongOrder(N1458,WorkPeriod);
}
void Set002_1(void)		//������������ʱ(��),����Ĭ��5��
{
	ShowLongOrder(N1460,DelayTime);
}
void Set003On_1(void)//��ͣ�Ǳ���0��ֹͣ�Ǳ�����0�������Ǳ���
{
	ShowOrder(N1411,0x0001);
}
void Set003Down_1(void)//��ͣ�Ǳ���0��ֹͣ�Ǳ�����0�������Ǳ���
{
	ShowOrder(N1411,0x0000);
}

void Set036_1(void)//ͨ�Ų����ʣ�1-9600��2-19200������Ĭ�ϣ���3-38400��4-57600��5-115200
{
	ShowLongOrder(N1408,BTL);
}

void Set037_1(void)//ͨ��У��λ��0-��У�飬1-żУ�飬2-��У�飨����λ�̶�8λ��У��λ��������λ֮��
{
	ShowLongOrder(N1428,BTL);
}

void Set038_1(void)//��������PWM��0��100������Ĭ��80
{
	ShowLongOrder(N1418,PumpPWM);
}

void Set041On_1(void)//����ģʽʹ�ܣ�0����ֹ����0��ʹ�ܣ�
{
	ShowOrder(N1413,0x0001);
}
void Set041Down_1(void)//����ģʽʹ�ܣ�0����ֹ����0��ʹ�ܣ�
{
	ShowOrder(N1413,0x0000);
}
void Set042_1(void)//���õ���
{
	ShowLongOrder(N1448,AirPumpResistance);
}
void Set043_1(void)//��ѹ��ֵ��
{
	ShowLongOrder(N1430,PressureLow);
}
void Set044_1(void)//��ѹ��ֵ��
{
	ShowLongOrder(N1438,PressureHigh);
}
void Set061_1(void)//0.1um �Ƚϵ�ѹ��0��8190
{
	ShowOrder(N14E8,ComparisonVoltage1);
}
void Set062_1(void)//0.15um �Ƚϵ�ѹ��0��8190
{
	ShowOrder(N14F0,ComparisonVoltage2);
}
void Set063_1(void)//0.2um �Ƚϵ�ѹ��0��8190
{
	ShowOrder(N14F8,ComparisonVoltage2);
}
void Set064_1(void)//0.25um �Ƚϵ�ѹ��0��8190
{
	ShowOrder(N1500,ComparisonVoltage4);
}
void Set065_1(void)//0.3um �Ƚϵ�ѹ��0��8190
{
	ShowOrder(N1508,ComparisonVoltage5);
}
void Set066_1(void)//0.5um �Ƚϵ�ѹ��0��8190
{
	ShowOrder(N1510,ComparisonVoltage6);
}
void Set067_1(void)//0.7�Ƚϵ�ѹ��0��8190
{
	ShowOrder(N1518,ComparisonVoltage7);
}
void Set068_1(void)//1.0�Ƚϵ�ѹ��0��8190
{
	ShowOrder(N1520,ComparisonVoltage8);
}


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//��ѹ0.1
//��ַ
//void Set000(void)	//N003
//{
//	ShowLongOrder(N1000,Address);
//}
////������
//void Set001(void)	//N005
//{
//	ShowLongOrder(N1008,BTL);
//}
////��������
//void Set002On(void)	//N001��N002
//{
//		//send_uart3_string("ID:SSSS202008N001*");
//	ShowOrder(N1811,0x0001);
//}
//void Set002Down(void)	//N001��N002
//{
//		//send_uart3_string("ID:SSSS202008N002*");
//	ShowOrder(N1811,0x0000);
//}
////����
//void Set003(void)	//N030
//{
//	ShowLongOrder(N1080,WorkPeriod);
//}
////��ʱ
//void Set004(void)	//N033
//{
//	ShowLongOrder(N1088,DelayTime);
//}
////����
//void Set006On(void)	//N100,101
//{
//		ShowOrder(N1C75,0x0001);
//}
//void Set006Down(void)	//N100,101
//{
//		ShowOrder(N1C75,0x0000);
//}
////�����ۼӴ���
//void Set010(void)	//N017
//{
//	ShowLongOrder(N1028,CumulativeFrequency);
//}
////�Ƚϵ�ѹ
//void Set011(void)	//N065
//{
//	ShowOrder(InputGear1,ComparisonVoltage1);
//}
//void Set012(void)	//N067
//{
//	ShowOrder(InputGear2,ComparisonVoltage2);
//}
//void Set013(void)	//N069
//{
//	ShowOrder(InputGear3,ComparisonVoltage3);
//}
//void Set014(void)	//N071
//{
//	ShowOrder(InputGear4,ComparisonVoltage4);
//}
//void Set015(void)	//N073
//{
//	ShowOrder(InputGear5,ComparisonVoltage5);
//}
//void Set016(void)	//N075
//{
//	ShowOrder(InputGear6,ComparisonVoltage6);
//}
//void Set017(void)	//N077
//{
//	ShowOrder(InputGear7,ComparisonVoltage7);
//}
//void Set018(void)	//N079
//{
//	ShowOrder(InputGear8,ComparisonVoltage8);
//}
////��ѹ��ֵ��
//void Set019(void)	//N038
//{
//	ShowLongOrder(N1030,PressureLow);
//}
////��ѹ��ֵ��
//void Set020(void)	//N039
//{
//	ShowLongOrder(N1038,PressureHigh);
//}
////��Դ��ֵ
//void Set023(void)	//N018
//{
//	ShowLongOrder(N1050,LightThreshold);
//}
//��Դ���ϲ�������
void Set072(void)
{
	ShowOrder(N1648,LightFailureMeasurement);
}
//�¶���ֵ
void Set073(void)
{
	ShowLongOrder(N1650,TemperatureThreshold);
}
//�趨����ͨ����
void Set075(void)
{
	ShowLongOrder(N1660,SetNumberChannels);
}
//�������
void Set076(void)
{
	ShowLongOrder(N1668,SamplingInterval);
}
//��������
void Set077(void)
{
	ShowLongOrder(N1670,SamplingFrequency);
}
//�趨����
void Set081(void)
{
	ShowLongOrder(N1688,SetFlow);
}
//�趨����ϵ��
void Set082(void)
{
	ShowLongOrder(N1690,SetGasCoefficient);
}
//PMT���Ƶ�ѹ
void Set083(void)
{
	ShowLongOrder(N1698,PMTControlVoltage);
}
//PMT����
void Set084(void)
{
	ShowLongOrder(N16A0,PMTResistance);
}
//����PWM
void Set086(void)
{
	ShowLongOrder(N16B0,AirPumpPWM);
}
//������ֵ87-88
void Set087(void)
{
	ShowLongOrder(N16B8,AlarmThreshold);
}
//IP
void Set106(void)
{
	ShowLongOrder(N15D0,IP1Data_5);
	ShowLongOrder(N15D8,IP2Data_5);
	ShowLongOrder(N15E0,IP3Data_5);
	ShowLongOrder(N15E8,IP4Data_5);
}
//Port
void Set110(void)
{
	ShowLongOrder(N15F0,PortData_5);
}
//IPandPort�޸�λ
void Set111(void)
{
	ShowLongOrder(N15F8,IPAndPortChange_5);
}
//���к�
void Set112(void)
{
	ShowLongOrder(N1710,SerialNumber1_5);
}
void Set113(void)
{
	ShowLongOrder(N1718,SerialNumber2_5);
}
void Set114(void)
{
	ShowLongOrder(N1720,SerialNumber3_5);
}
void Set115(void)
{
	ShowLongOrder(N1728,SerialNumber4_5);
}
void Set116(void)
{
	ShowLongOrder(N1730,SerialNumber5_5);
}
void Set117(void)
{
	ShowLongOrder(N1738,SerialNumber6_5);
}
void Set118(void)
{
	ShowLongOrder(N1740,SerialNumber7_5);
}
void Set119(void)
{
	ShowLongOrder(N1748,SerialNumber8_5);
}
//���к��޸�λ
void Set120(void)
{
	ShowLongOrder(N1750,SetSerialNumber_5);
}
//�趨Modbus�汾
void Set121(void)
{
	ShowLongOrder(N1758,SetModbusVersion);
}
//�趨�豸�汾��
void Set122(void)
{
	ShowLongOrder(N1760,SetDeviceVersion);
}




//-----------------------------------------------------------


//����8888���ֵ���ַ
void ShowDefineNum(u16 s_adress){
	
	ShowLongOrder(s_adress,8888);
}
//����8888���ֵ���ַ
void ShowDefineNum1(u16 s_adress){
	
	ShowOrder(s_adress,8888);
}

//�������ָ����ַ
void ShowOrder(u16 s_adress,u16 s_order)
{
	send_uart3(0x5A);
	send_uart3(0xA5);
	send_uart3(0x05);
	send_uart3(0x82);
	send_uart3(s_adress>>8);
	send_uart3(s_adress);	
	send_uart3(s_order>>8);
	send_uart3(s_order);
}
//���ͳ�ָ��
void ShowLongOrder(u16 s_adress,u32 s_order)
{
	send_uart3(0x5A);
	send_uart3(0xA5);
	send_uart3(0x07);
	send_uart3(0x82);
	send_uart3(s_adress>>8);
	send_uart3(s_adress);
	
	send_uart3(s_order>>24);
	send_uart3(s_order>>16);
	send_uart3(s_order>>8);
	send_uart3(s_order);
	
}
//�л�ҳ���ָ��
//ShowChooseOrder(0x0084,0x5A01000F);   000F Ϊָ��ҳ��
void ShowChooseOrder(u16 s_adress,u32 s_order)
{
	send_uart1(0x5A);
	send_uart1(0xA5);
	send_uart1(0x07);
	send_uart1(0x82);
	send_uart1(s_adress>>8);
	send_uart1(s_adress);
	
	send_uart1(s_order>>24);
	send_uart1(s_order>>16);
	send_uart1(s_order>>8);
	send_uart1(s_order);
	
}




