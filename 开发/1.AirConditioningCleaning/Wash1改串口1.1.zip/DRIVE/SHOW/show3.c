#include "show3.h"
#include "uart.h"
#include "communication.h"
#include "DataChange.h"
#include "show1.h"
#include "delay.h"
#include "equipment.h"

//485���ͼĴ�����������
//��Դ����״̬
void showLightState(u16 r_data)
{
	u16 crc;
	ModbusTx.Txbuf[0]=ModbusBroadcastAddress;
	ModbusTx.Txbuf[1]=0x06;
	ModbusTx.Txbuf[2]=0x00;
	ModbusTx.Txbuf[3]=0x18; 
	ModbusTx.Txbuf[4]=r_data>>8; 
	ModbusTx.Txbuf[5]=r_data;
	crc=crc16(ModbusTx.Txbuf,6);
	ModbusTx.Txbuf[6]=crc>>8;
	ModbusTx.Txbuf[7]=crc;
	ModbusTx.Txlen=8;
	ModbusSendOrder();//
	if(ModbusRx.ModbusReceDoneNum>=3)          		//Ӧ��������
	{
			ModbusRx.ModbusReceDoneNum=0;

	}
	else	//ͨ�ų�ʱ
	{
		
	}
}

