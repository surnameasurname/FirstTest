#ifndef __communication_h_
#define __communication_h_

#include "sys.h"
#include "communication1.h"
#include "communication3.h"

void communication_init(void);		//ͨ�ų�ʼ��
//����ָ���
void communication_order_dispose(void);


#endif
