#ifndef _show1_h_
#define _show1_h_
#include "sys.h"

void 	SetReceiveOrSend(u16 Temp);
void 	SetMode(u16 Temp);
void 	SetLocalGroupNumber(u16 Temp);
void 	SetLocalAddress(u16 Temp);
void 	SetTargetGroupNumber(u16 Temp);
void 	SetDestinationAddress(u16 Temp);
void 	SetPathGroupANumber(u16 Temp);
void 	SetPathAAddress(u16 Temp);
void 	SetPathGroupBNumber(u16 Temp);
void 	SetPathBAddress(u16 Temp);
void 	SetChannelAdd(u16 Temp);
void 	SetArmChannelAdd(u16 Temp);
void 	SetTempChannelAdd(u16 Temp);
#endif

