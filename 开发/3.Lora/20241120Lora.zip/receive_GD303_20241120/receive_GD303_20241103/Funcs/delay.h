#ifndef _DELAY_H_
#define _DELAY_H_


#include "gd32f30x.h"

void Delay_nus(uint64_t time);
void Delay_nms(uint64_t time);



#endif
