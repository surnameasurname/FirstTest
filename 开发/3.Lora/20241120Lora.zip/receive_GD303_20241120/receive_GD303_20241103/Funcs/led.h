#include "gd32f30x.h"
#include "usart0.h"


void delay_mine(uint32_t tt);
void led_init(void);
void led_on(void);
void led_off(void);




